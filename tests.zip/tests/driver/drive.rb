require 'selenium-webdriver'
require 'rubygems'

#Selenium::WebDriver::Chrome::Service.driver_path = "C:/chromedriver.exe"

driver = Selenium::WebDriver.for :chrome
driver.navigate.to "http://localhost:3000/attendances/"
if driver.find_element(:td , 'casa' ).displayed?
    puts "casaaaaaaa"
else 
    puts "nao encontradooo"
end

driver.navigate.to "http://localhost:3000/attendances/new"

if driver.find_element(:id , 'attendance_title' ).displayed?
    driver.find_element(:id , 'attendance_title').send_keys 'funcionario'
    puts "funcionario incluido no site"
else
    puts "falha em inserir"
end

sleep 10