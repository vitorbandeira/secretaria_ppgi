require 'selenium-webdriver'
require 'rubygems'


driver = Selenium::WebDriver.for :chrome



#if driver.find_element(:id , 'attendance_title' ).displayed?
#    driver.find_element(:id , 'attendance_title').send_keys 'funcionario'
#    driver.find_element(:id , 'attendance_content').send_keys 'exemplar e proativo'
#    puts "funcionario incluido no site"
#else
#    puts "falha em inserir"
#end


Dado("que acesso o banco e tem-se  informações a inserir") do
   
   driver.navigate.to "http://localhost:3000/attendances/new"
  end
  
  Quando("eu insiro {string} e {string}") do |string, string2|
    @string = string
    driver.find_element(:id , 'attendance_title').send_keys string # insere titulo
    sleep 2
    driver.find_element(:id , 'attendance_content').send_keys string2 # insere conteudo
    sleep 2
    driver.find_element(:name , 'commit').click # clica no botao cadastrar
    sleep 2
    
    
    
  end
  
  Entao("deve inserir com sucesso os dados no banco") do
    #expect(page).to have_content @string
  end
  
  Entao("receber a seguinte mensagem {string}") do |string|
    #expect(page).to have_content string
   # driver.navigate.to "http://localhost:3000/attendances/15"
    #if driver.find_element(id, 'notice').displayed?
    #    puts "sucesso"
    #else
    #    puts "fracasso"
    #end
  end
  



# sad path tentando inserir dado que já existe no banco
 
Dado("que tem-se  informações a inserir") do
   
  end

  Quando("insere-se {string} e {string}") do |string, string2|
  #  driver.find_element(:id , 'attendance_title').send_keys string # insere titulo
  #  driver.find_element(:id , 'attendance_content').send_keys string2 # insere conteudo
  #  driver.find_element(:name , 'commit').click # clica no botao cadastrar
  end
  
  Entao("não deve ser possível efetuar a ação, pois já existe tais dados no banco") do
    
  end
  Entao("receber o seguinte aviso {string}") do |string|
 #   driver.navigate.to "http://localhost:3000/attendances"
  end




  